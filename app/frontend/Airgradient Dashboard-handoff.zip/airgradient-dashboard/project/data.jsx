/* eslint-disable */
/* Mock data for AirGradient Air One kiosk */
const { useState, useEffect, useMemo, useRef } = React;

// ---- helpers ----
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function rand(seed) {
  let x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}
function smoothSeries(n, base, amp, seed = 1, drift = 0) {
  const out = [];
  let v = base;
  for (let i = 0; i < n; i++) {
    const r = rand(seed + i * 0.7) - 0.5;
    v += r * amp * 0.18 + drift;
    v = clamp(v, base - amp, base + amp * 1.4);
    out.push(v);
  }
  return out;
}

// PM2.5 24h (5 min cadence => 288 pts; we use 96 = 15min for clarity)
function build24hData() {
  const pm25 = smoothSeries(96, 14, 9, 11).map(v => Math.max(2, v));
  const pm10 = pm25.map((v, i) => v * (1.6 + (rand(i + 33) - 0.5) * 0.4));
  const co2  = smoothSeries(96, 760, 280, 17).map(v => Math.max(420, v));
  const tvoc = smoothSeries(96, 180, 90, 23).map(v => Math.max(40, v));
  return { pm25, pm10, co2, tvoc };
}

// AQI category from US AQI value
function aqiInfo(v) {
  if (v <= 50)  return { label: 'GOOD',         color: 'var(--aqi-1)', step: 1, msg: 'Air quality is satisfactory. Open windows freely.' };
  if (v <= 100) return { label: 'MODERATE',     color: 'var(--aqi-2)', step: 2, msg: 'Acceptable for most. Sensitive groups should monitor.' };
  if (v <= 150) return { label: 'UNHEALTHY (S)',color: 'var(--aqi-3)', step: 3, msg: 'Sensitive groups may experience symptoms.' };
  if (v <= 200) return { label: 'UNHEALTHY',    color: 'var(--aqi-4)', step: 4, msg: 'Everyone may begin to feel effects. Limit exertion.' };
  if (v <= 300) return { label: 'VERY UNHEALTHY',color:'var(--aqi-5)', step: 5, msg: 'Health alert. Avoid outdoor activity.' };
  return { label: 'HAZARDOUS', color: 'var(--aqi-6)', step: 6, msg: 'Emergency conditions. Stay indoors with filtration.' };
}

// Rooms/zones
const ZONES = [
  { id: 'living',  name: 'Living Room',  base: 38, amp: 8 },
  { id: 'kitchen', name: 'Kitchen',      base: 64, amp: 14 },
  { id: 'office',  name: 'Office',       base: 30, amp: 6 },
  { id: 'bedroom', name: 'Bedroom',      base: 22, amp: 5 },
  { id: 'lobby',   name: 'Lobby',        base: 52, amp: 10 },
];

// 7-day x 24h matrix for heatmap (PM2.5 hourly avg)
function buildWeekMatrix() {
  const days = ['MON','TUE','WED','THU','FRI','SAT','SUN'];
  return days.map((d, di) => {
    const row = [];
    for (let h = 0; h < 24; h++) {
      let base = 14;
      if (h >= 7 && h <= 9)  base += 12; // morning rush
      if (h >= 17 && h <= 21) base += 18; // evening cooking
      if (di >= 5) base += 4; // weekend slight bump
      const v = base + (rand(di * 31 + h) - 0.4) * 10;
      row.push(Math.max(3, v));
    }
    return { day: d, hours: row };
  });
}

const EVENTS = [
  { t: '14:32', lvl: 'warn', msg: 'PM2.5 spike in Kitchen — 64 µg/m³ peak' },
  { t: '14:18', lvl: 'info', msg: 'Calibration sync complete · NOx sensor' },
  { t: '13:55', lvl: 'ok',   msg: 'HEPA filter activated — auto mode' },
  { t: '12:40', lvl: 'info', msg: 'Ventilation cycle — 12 min run' },
  { t: '11:02', lvl: 'crit', msg: 'CO₂ threshold exceeded · Office · 1,420 ppm' },
  { t: '09:14', lvl: 'ok',   msg: 'All sensors nominal · uptime 142 d' },
  { t: '08:30', lvl: 'info', msg: 'Outdoor baseline updated · 12 µg/m³' },
];

window.AG = {
  build24hData, buildWeekMatrix, aqiInfo, ZONES, EVENTS,
  clamp, rand, smoothSeries
};

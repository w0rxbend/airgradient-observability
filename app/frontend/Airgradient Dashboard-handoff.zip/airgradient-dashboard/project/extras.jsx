/* eslint-disable */
const { useState, useEffect, useMemo } = React;

// ---------- Weekly Heatmap ----------
function WeekHeatmap({ matrix }) {
  // each cell colored by AQI step
  function color(v) {
    if (v < 12) return 'var(--aqi-1)';
    if (v < 25) return 'var(--aqi-2)';
    if (v < 40) return 'var(--aqi-3)';
    if (v < 60) return 'var(--aqi-4)';
    if (v < 90) return 'var(--aqi-5)';
    return 'var(--aqi-6)';
  }
  function opacity(v) { return 0.25 + Math.min(0.75, v / 80); }
  return (
    <div className="card week">
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title"><span className="index">/ 11</span> 7-day · hourly PM2.5</div>
        <span className="card-eyebrow">µg/m³ · zone agg</span>
      </div>
      <div className="heatmap">
        {matrix.map((row, ri) => (
          <React.Fragment key={ri}>
            <div className="heatmap-label">{row.day}</div>
            {row.hours.map((v, hi) => (
              <div key={hi} className="heatmap-cell" style={{ background: color(v), opacity: opacity(v) }} title={`${row.day} ${hi}:00 — ${v.toFixed(1)} µg/m³`} />
            ))}
          </React.Fragment>
        ))}
      </div>
      <div className="heatmap-hours" style={{display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', marginTop: 6, paddingLeft: 22}}>
        {[0,3,6,9,12,15,18,21].map(h => <span key={h}>{h.toString().padStart(2,'0')}</span>)}
      </div>
      <div style={{marginTop: 'auto', paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
        <div className="legend-row">
          {[1,2,3,4,5,6].map(i => (
            <span key={i} className="legend-item">
              <span style={{width: 10, height: 10, borderRadius: 2, background: `var(--aqi-${i})`}}/>
              {['0','12','25','40','60','90+'][i-1]}
            </span>
          ))}
        </div>
        <span style={{fontFamily: 'JetBrains Mono', fontSize: 10, color: 'var(--muted)'}}>168 obs · avg 18.4</span>
      </div>
    </div>
  );
}

// ---------- Events log ----------
function EventLog({ events }) {
  return (
    <div className="card events">
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title"><span className="index">/ 12</span> Event Log</div>
        <span className="card-eyebrow">last 24h</span>
      </div>
      <div className="events-list">
        {events.slice(0, 5).map((e, i) => (
          <div className="event-item" key={i}>
            <span className="event-time">{e.t}</span>
            <span className="event-msg" dangerouslySetInnerHTML={{__html: e.msg.replace(/(\d[\d,]*[ ]?(µg\/m³|ppm|°C|%|min|d))/g, '<b>$1</b>')}} />
            <span className={`event-level ${e.lvl}`}>{e.lvl}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- Zone overview (small) ----------
function ZoneStrip({ zones }) {
  return (
    <div className="card" style={{padding: '14px 18px'}}>
      <div className="card-hl" />
      <div className="card-header" style={{marginBottom: 8}}>
        <div className="card-title"><span className="index">/ 13</span> Zone Coverage</div>
        <span className="card-eyebrow">5 sensors online</span>
      </div>
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10}}>
        {zones.map((z, i) => {
          const info = AG.aqiInfo(z.value);
          return (
            <div key={z.id} style={{padding: '10px 12px', background: 'var(--ink-3)', border: '1px solid var(--line)', borderRadius: 8}}>
              <div style={{fontFamily: 'JetBrains Mono', fontSize: 9, color: 'var(--muted)', letterSpacing: '0.1em', textTransform: 'uppercase'}}>{z.name}</div>
              <div style={{fontFamily: 'JetBrains Mono', fontSize: 26, marginTop: 4, fontWeight: 500, letterSpacing: '-0.03em', color: 'var(--paper-0)'}}>{Math.round(z.value)}</div>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6}}>
                <span style={{fontFamily: 'JetBrains Mono', fontSize: 9, color: info.color}}>{info.label}</span>
                <span style={{width: 6, height: 6, borderRadius: '50%', background: info.color, boxShadow: `0 0 6px ${info.color}`}}/>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { WeekHeatmap, EventLog, ZoneStrip });

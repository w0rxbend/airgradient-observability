/* eslint-disable */
/* Charts & gauges (SVG-based, no libs) */
const { useMemo } = React;

// ---------- Sparkline ----------
function Sparkline({ data, color = 'var(--signal)', height = 40, width = 200, fill = true, stroke = 2 }) {
  const path = useMemo(() => {
    if (!data || data.length === 0) return { d: '', f: '' };
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = Math.max(0.001, max - min);
    const pts = data.map((v, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - ((v - min) / range) * (height - 4) - 2;
      return [x, y];
    });
    const d = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(' ');
    const f = `${d} L${width},${height} L0,${height} Z`;
    return { d, f };
  }, [data, width, height]);
  const gid = useMemo(() => 'sg-' + Math.random().toString(36).slice(2, 8), []);
  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={gid} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fill && <path d={path.f} fill={`url(#${gid})`} />}
      <path d={path.d} fill="none" stroke={color} strokeWidth={stroke} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

// ---------- Arc Gauge (AQI hero) ----------
function ArcGauge({ value, max = 300, segments, size = 280, thick = 22, label, sub, valueColor = 'var(--paper-0)' }) {
  const cx = size / 2;
  const cy = size / 2 + 20;
  const r = size / 2 - thick / 2 - 4;
  const start = Math.PI * 0.85;
  const end = Math.PI * 0.15 + Math.PI * 2;
  const span = end - start;
  const pct = clamp01(value / max);

  const pointAt = (t) => {
    const a = start + t * span;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  };
  const arc = (t0, t1, color) => {
    const [x0, y0] = pointAt(t0);
    const [x1, y1] = pointAt(t1);
    const large = t1 - t0 > 0.5 ? 1 : 0;
    return <path key={`${t0}-${t1}`} d={`M${x0},${y0} A${r},${r} 0 ${large} 1 ${x1},${y1}`} stroke={color} strokeWidth={thick} fill="none" strokeLinecap="butt" />;
  };

  const segs = segments || [
    { to: 50/max,  color: 'var(--aqi-1)' },
    { to: 100/max, color: 'var(--aqi-2)' },
    { to: 150/max, color: 'var(--aqi-3)' },
    { to: 200/max, color: 'var(--aqi-4)' },
    { to: 250/max, color: 'var(--aqi-5)' },
    { to: 1,       color: 'var(--aqi-6)' },
  ];

  // Needle endpoint
  const [nx, ny] = pointAt(pct);
  const needleAngle = (start + pct * span) * 180 / Math.PI;

  // ticks
  const ticks = [];
  for (let i = 0; i <= 10; i++) {
    const t = i / 10;
    const a = start + t * span;
    const r1 = r + thick/2 + 4;
    const r2 = r + thick/2 + (i % 5 === 0 ? 12 : 6);
    ticks.push(
      <line key={i}
        x1={cx + Math.cos(a) * r1} y1={cy + Math.sin(a) * r1}
        x2={cx + Math.cos(a) * r2} y2={cy + Math.sin(a) * r2}
        stroke="rgba(255,255,255,0.25)" strokeWidth="1" />
    );
  }

  let prev = 0;
  const arcs = segs.map((s) => {
    const node = arc(prev, s.to, s.color);
    prev = s.to;
    return node;
  });

  return (
    <svg viewBox={`0 0 ${size} ${size}`} width="100%" height="100%">
      {/* track */}
      <path d={`M${pointAt(0)[0]},${pointAt(0)[1]} A${r},${r} 0 1 1 ${pointAt(1)[0]},${pointAt(1)[1]}`}
        stroke="rgba(255,255,255,0.06)" strokeWidth={thick + 6} fill="none" strokeLinecap="butt" />
      {arcs}
      {ticks}
      {/* needle */}
      <g transform={`translate(${cx} ${cy})`}>
        <circle r="6" fill="var(--ink-1)" stroke="var(--paper-0)" strokeWidth="2" />
        <g transform={`rotate(${needleAngle})`}>
          <rect x={-2} y={-1.5} width={r - 8} height={3} rx={1.5} fill="var(--paper-0)" />
        </g>
        <circle r="3" fill="var(--paper-0)" />
      </g>
    </svg>
  );
}
function clamp01(v) { return Math.max(0, Math.min(1, v)); }

// ---------- Mini Radial (for CO2 etc) ----------
function MiniRadial({ value, max = 2000, color = 'var(--signal)', size = 130, thick = 12, label, unit }) {
  const cx = size / 2, cy = size / 2;
  const r = size / 2 - thick / 2 - 2;
  const pct = clamp01(value / max);
  const c = 2 * Math.PI * r;
  const offset = c * (1 - pct);
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} style={{transform: 'rotate(-90deg)'}}>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={thick} />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={thick}
        strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round"
        style={{transition: 'stroke-dashoffset 1s ease'}} />
    </svg>
  );
}

// ---------- Multi-line 24h chart ----------
function MultiLine({ series, height = 240, hours = 24 }) {
  // series: [{name, data, color}]
  const width = 800;
  const pad = { l: 36, r: 12, t: 16, b: 24 };
  const innerW = width - pad.l - pad.r;
  const innerH = height - pad.t - pad.b;

  const allMax = Math.max(...series.flatMap(s => s.data));
  const max = Math.ceil(allMax / 50) * 50;

  const xAt = (i, n) => pad.l + (i / (n - 1)) * innerW;
  const yAt = (v) => pad.t + innerH - (v / max) * innerH;

  const yLines = [];
  for (let i = 0; i <= 4; i++) {
    const v = (max / 4) * i;
    const y = yAt(v);
    yLines.push(
      <g key={i}>
        <line x1={pad.l} x2={width - pad.r} y1={y} y2={y} stroke="rgba(255,255,255,0.05)" strokeDasharray="2 4" />
        <text x={pad.l - 6} y={y + 3} textAnchor="end" fontFamily="JetBrains Mono" fontSize="9" fill="var(--muted)">{Math.round(v)}</text>
      </g>
    );
  }

  const hourTicks = [];
  for (let h = 0; h <= 24; h += 4) {
    const x = pad.l + (h / 24) * innerW;
    hourTicks.push(
      <text key={h} x={x} y={height - 6} textAnchor="middle" fontFamily="JetBrains Mono" fontSize="9" fill="var(--muted)">
        {h.toString().padStart(2, '0')}:00
      </text>
    );
  }

  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} preserveAspectRatio="none" style={{display: 'block'}}>
      <defs>
        {series.map((s, i) => (
          <linearGradient key={i} id={`ml-${i}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={s.color} stopOpacity="0.22" />
            <stop offset="100%" stopColor={s.color} stopOpacity="0" />
          </linearGradient>
        ))}
      </defs>
      {yLines}
      {hourTicks}
      {series.map((s, i) => {
        const pts = s.data.map((v, j) => [xAt(j, s.data.length), yAt(v)]);
        const d = pts.map((p, k) => k === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`).join(' ');
        const f = `${d} L${pts[pts.length-1][0]},${pad.t+innerH} L${pts[0][0]},${pad.t+innerH} Z`;
        return (
          <g key={i}>
            <path d={f} fill={`url(#ml-${i})`} />
            <path d={d} fill="none" stroke={s.color} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" />
          </g>
        );
      })}
      {/* now marker */}
      <line x1={pad.l + innerW} x2={pad.l + innerW} y1={pad.t} y2={pad.t + innerH} stroke="var(--signal)" strokeOpacity="0.4" strokeDasharray="3 3" />
      <circle cx={pad.l + innerW} cy={yAt(series[0].data[series[0].data.length-1])} r="3" fill="var(--signal)" />
    </svg>
  );
}

Object.assign(window, { Sparkline, ArcGauge, MiniRadial, MultiLine, clamp01 });

/* eslint-disable */
const { useState, useEffect, useMemo, useRef } = React;

function useClock() {
  const [t, setT] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setT(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return t;
}

function useLiveData() {
  const [tick, setTick] = useState(0);
  const baseRef = useRef(AG.build24hData());
  const originals = useRef({
    pm25: 14, pm10: 22, co2: 760, tvoc: 180
  });
  useEffect(() => {
    const id = setInterval(() => {
      const b = baseRef.current;
      ['pm25','pm10','co2','tvoc'].forEach(k => {
        const last = b[k][b[k].length - 1];
        const target = originals.current[k];
        const pull = (target - last) * 0.05; // soft restoring force
        const drift = (AG.rand(tick * 7 + k.charCodeAt(0)) - 0.5);
        const next = Math.max(1, last + drift * (k === 'co2' ? 18 : 1.2) + pull);
        b[k] = [...b[k].slice(1), next];
      });
      setTick(t => t + 1);
    }, 4000);
    return () => clearInterval(id);
  }, []);
  return baseRef.current;
}

function useScaleToFit() {
  useEffect(() => {
    const apply = () => {
      const el = document.querySelector('.canvas');
      if (!el) return;
      const sx = window.innerWidth / 1920;
      const sy = window.innerHeight / 1080;
      const s = Math.min(sx, sy);
      el.style.transform = `scale(${s})`;
    };
    apply();
    window.addEventListener('resize', apply);
    return () => window.removeEventListener('resize', apply);
  }, []);
}

function App() {
  useScaleToFit();
  const clock = useClock();
  const data = useLiveData();

  // Derive current readings from last sample
  const pm25 = data.pm25[data.pm25.length - 1];
  const pm10 = data.pm10[data.pm10.length - 1];
  const co2  = data.co2[data.co2.length - 1];
  const tvoc = data.tvoc[data.tvoc.length - 1];

  // Compute AQI from PM2.5 (simplified)
  const aqi = useMemo(() => {
    if (pm25 <= 12)   return (pm25 / 12) * 50;
    if (pm25 <= 35.4) return 50 + ((pm25 - 12) / (35.4 - 12)) * 50;
    if (pm25 <= 55.4) return 100 + ((pm25 - 35.4) / (55.4 - 35.4)) * 50;
    if (pm25 <= 150)  return 150 + ((pm25 - 55.4) / (150 - 55.4)) * 50;
    return 200 + Math.min(150, (pm25 - 150));
  }, [pm25]);

  const nox = 0.42;  // index value
  const tempV = 21.4 + Math.sin(clock.getSeconds() / 60 * Math.PI) * 0.3;
  const humV = 46 + Math.sin(clock.getSeconds() / 30) * 1.4;

  const tempSeries = useMemo(() => AG.smoothSeries(48, 21.4, 1.6, 99), []);
  const humSeries  = useMemo(() => AG.smoothSeries(48, 46, 6, 71), []);

  const week = useMemo(() => AG.buildWeekMatrix(), []);

  const timeStr = clock.toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  const dateStr = clock.toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase();

  const lastUpdate = `${clock.getSeconds() % 4}s`;

  return (
    <div className="stage">
      <div className="canvas">
        {/* HEADER */}
        <div className="topbar">
          <div className="brand">
            <div className="brand-mark">AG</div>
            <div className="brand-text">
              <span className="name">AIR ONE · KIOSK</span>
              <span className="sub">Device #AG-7F3E1A · Firmware 3.2.4 · MAC E8:DB:84</span>
            </div>
          </div>
          <div className="crumbs">
            <span className="item active"><span className="dot active"/> OVERVIEW</span>
            <span className="item"><span className="dot"/> SENSORS</span>
            <span className="item"><span className="dot"/> HISTORY</span>
            <span className="item"><span className="dot"/> REPORTS</span>
            <span className="item"><span className="dot"/> SYSTEM</span>
          </div>
          <div className="topbar-right">
            <span className="netpill"><span className="led"/> ONLINE</span>
            <span style={{fontSize: 11, color: 'var(--muted)'}}>UPLINK <b className="mono" style={{color:'var(--paper-0)'}}>{lastUpdate}</b> AGO</span>
            <div className="clock">
              <span className="date">{dateStr}</span>
              <span className="time mono">{timeStr}</span>
            </div>
          </div>
        </div>

        {/* GRID */}
        <div className="grid">
          {/* Row 1 */}
          <HeroAQI value={aqi} />
          <TrendCard data={data} />
          <AdvisoryCard value={aqi} />

          {/* Row 2 */}
          <CO2Card value={co2} series={data.co2} />
          <StatTile idx={5} label="PM2.5" value={pm25.toFixed(1)} unit="µg/m³"
            tileClass="tile-pm25" compact
            sub={`0.3–2.5 µm fraction`}
            status={pm25 < 12 ? 'GOOD' : pm25 < 25 ? 'MOD' : 'HIGH'}
            color={pm25 < 12 ? 'var(--aqi-1)' : pm25 < 25 ? 'var(--aqi-2)' : 'var(--aqi-4)'}
            sparkline={data.pm25}
            deltaText="−2.3%"
            deltaDir="down"
            rampStep={pm25 < 12 ? 1 : pm25 < 25 ? 2 : pm25 < 40 ? 3 : 4}
          />
          <StatTile idx={6} label="PM10" value={pm10.toFixed(1)} unit="µg/m³"
            tileClass="tile-pm10" compact
            sub={`coarse fraction`}
            status={pm10 < 25 ? 'GOOD' : pm10 < 50 ? 'MOD' : 'HIGH'}
            color={pm10 < 25 ? 'var(--aqi-1)' : pm10 < 50 ? 'var(--aqi-2)' : 'var(--aqi-4)'}
            sparkline={data.pm10}
            deltaText="+0.8 µg"
            deltaDir="up"
            rampStep={pm10 < 25 ? 1 : pm10 < 50 ? 2 : 3}
          />
          <StatTile idx={7} label="TVOC" value={Math.round(tvoc)} unit="ppb"
            tileClass="tile-tvoc" compact
            sub="SGP41 idx 178"
            status="OK"
            color="var(--signal)"
            sparkline={data.tvoc}
            deltaText="stable"
            deltaDir="flat"
            rampStep={2}
          />
          <StatTile idx={8} label="NOx" value={(nox*100).toFixed(0)} unit="idx"
            tileClass="tile-nox" compact
            sub="1h scaled 0–100"
            status="LOW"
            color="var(--green)"
            sparkline={AG.smoothSeries(48, 42, 18, 13)}
            deltaText="−5%"
            deltaDir="down"
            rampStep={1}
          />

          {/* Row 3 */}
          <TempCard value={tempV} series={tempSeries} />
          <HumCard value={humV} series={humSeries} />
          <WeekHeatmap matrix={week} />
          <EventLog events={AG.EVENTS} />
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

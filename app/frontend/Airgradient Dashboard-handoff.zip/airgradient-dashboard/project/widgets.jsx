/* eslint-disable */
/* Widget components */
const { useState, useEffect, useMemo } = React;

// ---------- Hero AQI ----------
function HeroAQI({ value, blurb }) {
  const info = AG.aqiInfo(value);
  return (
    <div className="card hero">
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title">
          <span className="index">/ 01</span> Air Quality Index
        </div>
        <div className="hero-flag">
          <span className="hero-flag-bar"><i></i><i></i></span>
          KYIV · UA
        </div>
      </div>
      <div className="aqi-wrap">
        <div className="aqi-number-wrap">
          <div className="aqi-status" style={{ color: info.color, background: `color-mix(in oklab, ${info.color} 14%, transparent)`, borderColor: `color-mix(in oklab, ${info.color} 35%, transparent)` }}>
            <span className="led" /> {info.label}
          </div>
          <div className="aqi-number">
            {Math.round(value)}<span className="aqi-unit">US&nbsp;AQI</span>
          </div>
          <div className="aqi-blurb">{blurb || info.msg}</div>
          <div className="ramp" style={{marginTop: 12}}>
            {[1,2,3,4,5,6].map(i => (
              <i key={i} className={info.step >= i ? 'on' : ''} style={{background: `var(--aqi-${i})`}} />
            ))}
          </div>
        </div>
        <div className="gauge">
          <ArcGauge value={value} max={300} size={300} thick={18} />
        </div>
      </div>
    </div>
  );
}

// ---------- 24h Trend ----------
function TrendCard({ data }) {
  return (
    <div className="card trend">
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title">
          <span className="index">/ 02</span> 24-hour pollutant trend
        </div>
        <div className="row-flex">
          <div className="legend-row">
            <span className="legend-item"><span className="legend-swatch" style={{background: 'var(--signal)'}}/>PM2.5</span>
            <span className="legend-item"><span className="legend-swatch" style={{background: 'var(--diia)'}}/>PM10</span>
            <span className="legend-item"><span className="legend-swatch" style={{background: 'var(--amber)'}}/>TVOC</span>
          </div>
          <span className="tag live"><span className="led" /> LIVE</span>
        </div>
      </div>
      <div style={{flex: 1, display: 'flex', alignItems: 'stretch', minHeight: 0}}>
        <MultiLine height={210} series={[
          { name: 'PM2.5', data: data.pm25, color: 'var(--signal)' },
          { name: 'PM10',  data: data.pm10, color: 'var(--diia)' },
          { name: 'TVOC',  data: data.tvoc.map(v => v / 6), color: 'var(--amber)' },
        ]} />
      </div>
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginTop: 10, paddingTop: 10, borderTop: '1px dashed var(--line)'}}>
        <MiniStat label="24h avg PM2.5" value={`${(data.pm25.reduce((a,b)=>a+b,0)/data.pm25.length).toFixed(1)}`} unit="µg/m³" />
        <MiniStat label="Peak"        value={`${Math.max(...data.pm25).toFixed(0)}`} unit="µg/m³" delta="14:32" />
        <MiniStat label="Low"         value={`${Math.min(...data.pm25).toFixed(0)}`} unit="µg/m³" delta="03:18" />
        <MiniStat label="WHO 24h"     value="15"   unit="µg/m³" delta="ref" />
      </div>
    </div>
  );
}
function MiniStat({ label, value, unit, delta }) {
  return (
    <div className="flex-col" style={{gap: 2}}>
      <span style={{fontFamily: 'JetBrains Mono', fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)'}}>{label}</span>
      <span style={{fontFamily: 'JetBrains Mono', fontSize: 18, fontWeight: 500, letterSpacing: '-0.02em'}}>{value} <span style={{fontSize: 10, color: 'var(--muted)'}}>{unit}</span></span>
      {delta && <span style={{fontFamily: 'JetBrains Mono', fontSize: 9, color: 'var(--muted)'}}>{delta}</span>}
    </div>
  );
}

// ---------- Advisory ----------
function AdvisoryCard({ value }) {
  const info = AG.aqiInfo(value);
  return (
    <div className="card advisory">
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title">
          <span className="index">/ 03</span> Health Advisory
        </div>
        <span className="tag" style={{color: info.color, borderColor: `color-mix(in oklab, ${info.color} 40%, transparent)`}}>
          <span className="led" style={{background: info.color, boxShadow: `0 0 8px ${info.color}`}}/> LEVEL&nbsp;{info.step}/6
        </span>
      </div>
      <div className="advisory-body">
        <div className="advisory-headline">
          {info.step <= 2 ? 'Breathe easy — conditions favorable for all activities.'
            : info.step === 3 ? 'Sensitive groups should reduce prolonged exertion.'
            : 'Limit outdoor activity. Enable filtration.'}
        </div>
        <div>
          <div className="advisory-rec"><span className="icon">01</span><div><b>Ventilation</b> &nbsp;Auto-cycle every 45 min · windows open during low-pollen window 04–07.</div></div>
          <div className="advisory-rec"><span className="icon">02</span><div><b>Activity</b> &nbsp;Suitable for indoor exercise. Outdoor running OK in zones 1–2.</div></div>
          <div className="advisory-rec"><span className="icon">03</span><div><b>Filter</b> &nbsp;HEPA H13 · 84% capacity remaining · est. 32 days.</div></div>
        </div>
        <div className="compare-bar">
          <CompareRow lbl="vs WHO"   pct={0.42} color="var(--green)"  val="42%" note="of limit" />
          <CompareRow lbl="vs Outdoor" pct={0.68} color="var(--amber)" val="68%" />
          <CompareRow lbl="vs 30-day" pct={0.31} color="var(--signal)" val="−12%" />
        </div>
      </div>
    </div>
  );
}
function CompareRow({ lbl, pct, color, val }) {
  return (
    <div className="compare-row">
      <span className="lbl">{lbl}</span>
      <span className="track"><span className="fill" style={{width: `${pct*100}%`, background: color}}/></span>
      <span className="val">{val}</span>
    </div>
  );
}

// ---------- Stat Tile ----------
function StatTile({ idx, label, value, unit, sub, status, sparkline, deltaText, deltaDir, color, rampStep, max, tileClass, compact }) {
  return (
    <div className={`card stat ${tileClass || ''} ${compact ? 'stat-compact' : ''}`} style={{color: color}}>
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title"><span className="index">/ {String(idx).padStart(2,'0')}</span> {label}</div>
        {status && <span className="tag" style={{color, borderColor: `color-mix(in oklab, ${color} 40%, transparent)`}}><span className="led" style={{background: color, boxShadow: `0 0 8px ${color}`}}/> {status}</span>}
      </div>
      <div className="stat-value" style={{color: 'var(--paper-0)'}}>
        {value}<span className="unit">{unit}</span>
      </div>
      {sub && <div style={{fontFamily: 'JetBrains Mono', fontSize: 11, color: 'var(--muted)', marginTop: 4}}>{sub}</div>}
      {sparkline && (
        <div className="stat-spark">
          <Sparkline data={sparkline} color={color} height={36} stroke={1.6} />
        </div>
      )}
      {rampStep && (
        <div className="ramp">
          {[1,2,3,4,5,6].map(i => (
            <i key={i} className={rampStep >= i ? 'on' : ''} style={{background: `var(--aqi-${i})`}} />
          ))}
        </div>
      )}
      <div className="stat-meta">
        <span>{deltaText && <span className={`delta ${deltaDir || 'flat'}`}>{deltaDir === 'up' ? '↗' : deltaDir === 'down' ? '↘' : '·'} {deltaText}</span>}</span>
        <span>{max ? `max ${max}` : ''}</span>
      </div>
    </div>
  );
}

// ---------- CO2 with radial ----------
function CO2Card({ value, series }) {
  const status = value < 800 ? { txt: 'OK',         color: 'var(--green)'} :
                 value < 1200 ? { txt: 'ELEVATED',  color: 'var(--amber)'} :
                                { txt: 'HIGH',      color: 'var(--aqi-5)'};
  return (
    <div className="card stat tile-co2" style={{color: status.color}}>
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title"><span className="index">/ 04</span> CO₂ · Carbon Dioxide</div>
        <span className="tag" style={{color: status.color, borderColor: `color-mix(in oklab, ${status.color} 40%, transparent)`}}>
          <span className="led" style={{background: status.color, boxShadow: `0 0 8px ${status.color}`}}/> {status.txt}
        </span>
      </div>
      <div style={{display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, alignItems: 'center', flex: 1}}>
        <div>
          <div className="stat-value" style={{color: 'var(--paper-0)', fontSize: 64}}>
            {Math.round(value)}<span className="unit">ppm</span>
          </div>
          <div style={{display: 'flex', gap: 16, marginTop: 12, fontFamily: 'JetBrains Mono', fontSize: 10, color: 'var(--muted)'}}>
            <span>OUTDOOR <b style={{color:'var(--paper-1)'}}>415</b></span>
            <span>TARGET <b style={{color:'var(--paper-1)'}}>&lt;800</b></span>
            <span>MAX 24H <b style={{color:'var(--paper-1)'}}>{Math.round(Math.max(...series))}</b></span>
          </div>
          <div style={{marginTop: 12}}>
            <Sparkline data={series} color={status.color} height={32} stroke={1.6} />
          </div>
        </div>
        <div style={{width: 130, height: 130, position: 'relative'}}>
          <MiniRadial value={value} max={2000} color={status.color} />
          <div style={{position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', fontFamily: 'JetBrains Mono', fontSize: 11, color: 'var(--muted)', textAlign: 'center'}}>
            <div>
              <div style={{fontSize: 22, color: 'var(--paper-0)', fontWeight: 500, letterSpacing: '-0.02em'}}>{Math.round((value/2000)*100)}%</div>
              <div style={{fontSize: 9, letterSpacing: '0.1em', textTransform: 'uppercase'}}>of cap</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- Temp / Humidity ----------
function TempCard({ value, series }) {
  return (
    <div className="card temp" style={{color: 'var(--amber)'}}>
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title"><span className="index">/ 09</span> Temperature</div>
        <span className="tag" style={{color: 'var(--amber)', borderColor: 'color-mix(in oklab, var(--amber) 40%, transparent)'}}>
          <span className="led" style={{background: 'var(--amber)', boxShadow: '0 0 8px var(--amber)'}}/> NORMAL
        </span>
      </div>
      <div className="bigreading">
        <div>
          <div style={{fontFamily: 'JetBrains Mono', fontSize: 11, color: 'var(--muted)', letterSpacing: '0.08em'}}>INDOOR · LIVING ROOM</div>
          <div className="value">{value.toFixed(1)}<span style={{fontSize: 28, color: 'var(--muted)', marginLeft: 6}}>°C</span></div>
        </div>
        <Sparkline data={series} color="var(--amber)" height={48} stroke={1.8} />
        <div className="row">
          <span>HIGH <b>22.8°</b></span>
          <span>LOW <b>19.4°</b></span>
          <span>FEELS <b>{(value+0.6).toFixed(1)}°</b></span>
          <span>OUTDOOR <b>11°</b></span>
        </div>
      </div>
    </div>
  );
}
function HumCard({ value, series }) {
  const status = value < 30 ? 'DRY' : value > 60 ? 'HUMID' : 'OPTIMAL';
  const c = value < 30 ? 'var(--amber)' : value > 60 ? 'var(--diia)' : 'var(--green)';
  return (
    <div className="card hum" style={{color: c}}>
      <div className="card-hl" />
      <div className="card-header">
        <div className="card-title"><span className="index">/ 10</span> Humidity</div>
        <span className="tag" style={{color: c, borderColor: `color-mix(in oklab, ${c} 40%, transparent)`}}>
          <span className="led" style={{background: c, boxShadow: `0 0 8px ${c}`}}/> {status}
        </span>
      </div>
      <div className="bigreading">
        <div>
          <div style={{fontFamily: 'JetBrains Mono', fontSize: 11, color: 'var(--muted)', letterSpacing: '0.08em'}}>RELATIVE · LIVING ROOM</div>
          <div className="value">{value.toFixed(0)}<span style={{fontSize: 28, color: 'var(--muted)', marginLeft: 6}}>%</span></div>
        </div>
        <Sparkline data={series} color={c} height={48} stroke={1.8} />
        <div className="row">
          <span>DEW POINT <b>9.2°</b></span>
          <span>VPD <b>0.84 kPa</b></span>
          <span>TARGET <b>40–60%</b></span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { HeroAQI, TrendCard, AdvisoryCard, StatTile, CO2Card, TempCard, HumCard });
